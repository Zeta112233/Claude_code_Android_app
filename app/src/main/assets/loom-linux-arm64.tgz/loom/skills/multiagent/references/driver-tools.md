# Driver MCP Tools

The driver runs as a stdio MCP server inside Claude Code and also registers as an agentserver workspace agent. Prefer contract tools for business tasks; use direct helpers for explicit low-level control.

## Capability Discovery

### `list_agents`

Input:

```json
{"include_unavailable": false}
```

Returns currently `available` agents excluding the current driver itself. Offline
and busy agents are omitted unless `include_unavailable:true` is passed. Each
result includes `status` and `role`; use `role` instead of display-name
heuristics to distinguish drivers, masters, and slaves.

```json
{
  "agents": [
    {
      "agent_id": "sandbox-id",
      "display_name": "slave-windows",
      "status": "available",
      "role": "slave",
      "short_id": "abc123",
      "platform": {"os": "windows", "arch": "amd64"},
      "command_interfaces": [
        {"skill": "powershell", "kind": "powershell", "command": "powershell.exe", "default": true}
      ],
      "skills": ["chat", "mcp", "register_mcp", "powershell", "file", "permissions"],
      "tools": ["legacy_tool_name"],
      "mcp_tools": [{"server": "srv", "name": "tool", "input_schema": {}}],
      "resources": {"tags": ["python3"]}
    }
  ]
}
```

`role` is one of `driver`, `master`, or `slave`. Agent cards with an explicit
`agent_type` of `driver`, `master`, or `slave` use that value; otherwise agents
advertising `fanout`, `route`, or `fanout_strict` are treated as `master`, and
remaining returned agents are treated as `slave`.

Set `include_unavailable:true` only for diagnostics or cleanup; normal routing
and "who is online" answers should use the default available-only result.

### `list_driver_tasks`

Input:

```json
{"limit": 50, "task_id": "optional-task-id"}
```

Returns locally recorded driver-created delegated task IDs, newest first:

```json
{
  "journal_path": "/home/agent/.cache/multi-agent/drv-001/driver-tasks.jsonl",
  "warnings": [],
  "tasks": [
    {
      "ts": "2026-06-12T03:30:00Z",
      "event": "delegate_task",
      "tool": "run_slave_bash",
      "task_id": "task-abc",
      "target_id": "agent-123",
      "target_display_name": "slave-local-prod",
      "skill": "bash",
      "status": "submitted",
      "wait": true,
      "timeout_sec": 600
    }
  ]
}
```

Use this after an interrupted or timed-out long driver `tools/call` before
deciding the task was never created. The journal records metadata only; it
does not include prompts, scripts, environment variables, file contents,
tokens, or credentials. If the journal contains malformed JSONL lines, the
tool skips those lines and returns `warnings`; valid older task records remain
recoverable.

### `inspect_capabilities`

Input:

```json
{"save_snapshot": true}
```

Returns a resource snapshot plus visible agents, slaves, flattened `mcp_tools`, and `warnings`. Use it before drafting contracts.

## Contract Tools

### `draft_task_contract`

Input:

```json
{
  "goal": "Compare two matrix multiplication implementations on two slaves",
  "business_context": "Need reproducible evidence",
  "success_criteria": ["Both scripts run", "Results match"],
  "write_targets": [{"type": "artifact", "kind": "document", "name": "report.md"}],
  "required_skills": ["bash"],
  "required_tools": [],
  "resources": {"tags": ["python3"]},
  "routing": "direct_first",
  "max_concurrency": 2,
  "allowed_targets": []
}
```

Returns `contract` and `clarification_questions`.

### `dry_run_contract`

Input:

```json
{"contract": {"version": 1}}
```

Returns:

```json
{
  "runnable": true,
  "recommended_route": "driver_fanout",
  "recommended_target_id": "",
  "recommended_target_display_name": "",
  "recommended_skill": "fanout",
  "satisfied_tools": [],
  "missing_tools": [],
  "missing_skills": [],
  "reasons": ["driver can orchestrate with currently advertised tools"]
}
```

Never submits work and never creates MCP servers.

### `submit_contract_task`

Input:

```json
{
  "contract": {"version": 1},
  "prompt": "Optional execution detail; defaults to contract.intent.goal",
  "target_display_name": "optional explicit target",
  "skill": "optional skill override",
  "timeout_sec": 1200
}
```

Behavior:

- Encodes the contract envelope and saves resource/contract snapshots through observer when configured.
- If `recommended_route` is `driver_fanout` and no target override is supplied, the driver runs its own DAG runner.
- Otherwise delegates to a direct slave according to target and contract policy.

## Direct Task Tools

### `submit_task`

Use for simple ad hoc direct tasks. Prefer `submit_contract_task` for coordinated work. Input:

```json
{
  "prompt": "Do the task",
  "read_paths": ["/absolute/local/input.csv"],
  "write_paths": [{"path": "/absolute/local/out.md", "overwrite": true}],
  "target_display_name": "slave-a",
  "skill": "fanout",
  "timeout_sec": 1200
}
```

`read_paths` and `write_paths` are driver-local paths. The driver converts them into file manifests and observer or peer-proxy URLs for remote agents.

The response now includes `session_id` (from the agentserver
`DelegateTaskResponse`). For chat tasks this is the backend session id that
ties together follow-up `resume_task` calls; for non-chat skills it may be
empty — ignore it.

### `get_task`

Input:

```json
{"task_id": "task-id", "include_subtasks": true}
```

Returns status, output, latest progress, final output, and whether the task is final.

May also return the `awaiting_user` variant described under `wait_task`
below — chat tasks paused mid-conversation surface the same way through
`get_task`.

### `wait_task`

Input:

```json
{"task_id": "task-id", "poll_interval_sec": 3, "timeout_sec": 1200}
```

Blocks until terminal status and returns `written_files` for PUT-back outputs.

**`awaiting_user` variant** (chat task paused mid-conversation):

```json
{
  "status": "awaiting_user",
  "is_final": false,
  "session_id": "S-uuid",
  "current_task_id": "T-1",
  "target_id": "ag-X",
  "question": {
    "kind": "ask_user | request_permission",
    "question": "...",
    "options": ["..."],
    "context": "...",
    "intent": "...", "target": "...", "reason": "..."
  }
}
```

When you see this, surface the question to the human via
`AskUserQuestion`, then call `resume_task(last_task_id=current_task_id,
answer=...)`. Loop until `status:"completed"`.

### `resume_task`

Input:

```json
{
  "last_task_id": "T-1",
  "answer": "the user's reply",
  "timeout_sec": 600
}
```

Continues a chat task that `wait_task` returned as
`status:"awaiting_user"`. The driver is **stateless**: it re-reads
`last_task_id` via `GetTask` to recover `session_id` and `target_id`, then
delegates a new `chat_resume` task to the same slave.

Returns the same shape as `wait_task` — may itself be another
`awaiting_user` (multi-round questions), or a final `completed`, or
`failed` / `cancelled` if the resume fails on the slave (session not found,
slave offline, etc.).

### `tail_subtasks`

Input:

```json
{"task_id": "task-id", "since_seq": 0, "max_wait_sec": 30}
```

Long-polls subtask rows and returns `{cursor, events}` for a delegated task.

### `cancel_task`

Input:

```json
{"task_id": "task-id"}
```

Currently a v1 stub: returns current status and notes that cancel is not implemented.

## Slave Control Helpers

Shell helpers default to asynchronous submission: if `wait` is omitted or
`false`, the tool returns `task_id`, target metadata, skill, and initial status
without waiting for the remote command. Pass `"wait": true` only for short
commands where blocking the MCP call until completion is intentional. For long
commands, keep the default and poll with `get_task`, `wait_task`, or
`tail_subtasks`.

### `run_slave_bash`

Input:

```json
{
  "target_agent_id": "optional",
  "target_display_name": "slave-a",
  "script": "python3 - <<'PY'\nprint('ok')\nPY",
  "env": {"KEY": "value"},
  "timeout_sec": 60,
  "wait": false
}
```

Requires target skill `bash` and a Bash command interface in
`command_interfaces`. Bash means real Bash only: this helper does not execute
PowerShell on Windows and must not be used as a generic shell fallback.
Delegates `skill:"bash"` with JSON prompt.

### `run_slave_powershell`

Input:

```json
{
  "target_agent_id": "optional",
  "target_display_name": "win-slave",
  "script": "Get-ChildItem -Path . | Select-Object -First 5",
  "env": {"KEY": "value"},
  "timeout_sec": 60,
  "wait": false
}
```

Requires target skill `powershell` and a PowerShell command interface in
`command_interfaces`. Use this for Windows-native command execution. The
driver delegates `skill:"powershell"` with a JSON prompt and does not route
through Bash.

### `run_slave_shell`

Input:

```json
{
  "target_agent_id": "optional",
  "target_display_name": "any-slave",
  "script": "python --version",
  "env": {"KEY": "value"},
  "timeout_sec": 60,
  "wait": false
}
```

Use this when the command is intentionally shell-agnostic. The driver reads the
target card's `command_interfaces`, chooses the entry marked `default:true`,
and delegates to `skill:"powershell"` or `skill:"bash"` accordingly. Windows
targets default to PowerShell, while Linux / macOS targets typically default to
Bash. If a legacy card omits `command_interfaces` but advertises `bash`, the
driver treats it as legacy Bash. Prefer `run_slave_bash` or
`run_slave_powershell` when the script depends on syntax specific to one shell.

### `register_slave_mcp`

Input:

```json
{
  "target_agent_id": "optional",
  "target_display_name": "slave-a",
  "spec": {
    "name": "row_stats",
    "description": "Compute statistics for rows",
    "version": 1,
    "tools": [
      {
        "name": "summarize_rows",
        "description": "Summarize numeric row values",
        "args_schema": {"type":"object","properties":{"rows":{"type":"array"}},"required":["rows"]},
        "result_description": "JSON summary"
      }
    ],
    "allowed_packages": []
  },
  "source_path": "generated_mcp/row_stats/v1.py",
  "timeout_sec": 60
}
```

Requires target skill `register_mcp`. Delegates `skill:"register_mcp"` with the JSON above. Use after the source has been written with file tools and validated through the target's advertised shell interface.

### `get_slave_claude_permissions`

Input:

```json
{"target_agent_id": "optional", "target_display_name": "slave-a"}
```

Requires target skill `permissions` or the legacy alias `claude_permissions`. Delegates prompt `{"op":"get"}` through the current compatibility channel.

### `update_slave_claude_permissions`

Input:

```json
{
  "target_display_name": "slave-a",
  "allow_presets": ["python", "curl", "file_write"],
  "allow_add": ["Bash(python3 *)"],
  "allow_remove": [],
  "deny_add": [],
  "deny_remove": []
}
```

Requires target skill `permissions` or the legacy alias `claude_permissions`. Uses the task channel today; future design should move this to a dedicated agentserver control channel.
The driver tool keeps the user-facing `allow_presets` input name, but delegates the generic permissions patch field as `presets` for both `permissions` and `claude_permissions` targets.

## Slave File Tools

In-band file I/O against a slave that advertises `file`. Bytes flow through the driver's `FileRegistry` (sha256-keyed cache under `logs/file-cache/`), so payloads never need to live in the LLM context as tool arguments or results. Slave-side semantics are documented in `slave-skills.md` under `file`.

Prefer these over `run_slave_bash "cat ..."` / base64-in-bash payloads whenever you actually want bytes (uploading an MCP server source, pulling back a log, copying between slaves). Prefer the PUT-manifest path (`submit_task.read_paths`/`write_paths`) for large artifacts that should live in observer storage.

### `read_slave_file`

Input:

```json
{
  "target_agent_id": "optional",
  "target_display_name": "slave-a",
  "path": "data/in.csv",
  "offset": 0,
  "length": 65536,
  "encoding": "utf-8",
  "inline_max_bytes": 65536
}
```

- `path` resolves against the slave's `claude.workdir` if relative; absolute paths are used as-is.
- `encoding`: `"utf-8"` (default) or `"base64"` for binary-safe transfer.
- `offset` / `length` chunk large files (slave caps a single read at 8 MiB).
- `inline_max_bytes` controls whether `content` is returned inline; bytes are always cached.

Result:

```json
{
  "slave_path": "data/in.csv",
  "size": 41,
  "sha256": "f38d...",
  "blob_handle": "sha256:f38d...",
  "cache_path": "logs/file-cache/f38d...",
  "encoding": "utf-8",
  "content": "...optional inline...",
  "eof": true
}
```

`blob_handle` is the stable reference. Pass it back into `write_slave_file` as `source_blob` to push the same bytes to another slave without re-fetching. `cache_path` is a driver-local file you can hand to the `Read` tool when you actually need to inspect the bytes.

### `write_slave_file`

Input — exactly one of `content` / `source_blob` / `source_path` is required:

```json
{
  "target_display_name": "slave-a",
  "path": "generated_mcp/foo/v1.py",
  "mode": "overwrite",
  "mkdir": true,
  "encoding": "utf-8",
  "content": "...inline string..."
}
```

```json
{
  "target_display_name": "slave-b",
  "path": "data/copy.bin",
  "source_blob": "sha256:f38d..."
}
```

```json
{
  "target_display_name": "slave-a",
  "path": "generated_mcp/foo/v1.py",
  "source_path": "/abs/driver/path/v1.py"
}
```

- `mode`: `overwrite` | `append` | `create_new` | `patch`. `offset` is only valid with `patch`.
- `source_path` (driver-local absolute path) gets registered in `FileRegistry` on the way through, so the resulting handle is available for subsequent fanout.
- `source_blob` must reference a handle the driver already knows (returned by a prior `read_slave_file` or `write_slave_file source_path`).

Result: `{slave_path, bytes_written, mode, source}`.

### `stat_slave_file`

Input:

```json
{"target_display_name": "slave-a", "path": "generated_mcp/foo/v1.py"}
```

Result: `{slave_path, exists, size?, mode?, is_dir?, mtime?}`. Missing paths return `exists:false` — not an error — so it's cheap to probe before writing.

### Cross-slave copy pattern

```text
read_slave_file(target=A, path=src)        -> {blob_handle: H, ...}
write_slave_file(target=B, path=dst, source_blob=H)
```

The bytes round-trip through the driver's `FileRegistry`, never through chat or `run_slave_bash`. Use this instead of routing through observer artifacts when both endpoints are slaves currently advertising `file` and the payload fits comfortably in driver-local cache.
